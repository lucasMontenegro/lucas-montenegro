--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.7 (Debian 11.7-1.pgdg90+1)
-- Dumped by pg_dump version 11.7 (Debian 11.7-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE lib__node__postgres;
--
-- Name: lib__node__postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE lib__node__postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


\connect lib__node__postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: unique_constraint_example_table; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unique_constraint_example_table (
    id character varying(10) NOT NULL,
    created_on timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Data for Name: unique_constraint_example_table; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unique_constraint_example_table (id, created_on) FROM stdin;
\.
COPY public.unique_constraint_example_table (id, created_on) FROM '$$PATH$$/2862.dat';

--
-- Name: unique_constraint_example_table unique_constraint_example_table_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unique_constraint_example_table
    ADD CONSTRAINT unique_constraint_example_table_id_key UNIQUE (id);


--
-- PostgreSQL database dump complete
--

